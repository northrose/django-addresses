from django.apps import AppConfig

class ContactInfoConfig(AppConfig):
    name = 'contact_info'
    verbose_name = 'Contact Information'