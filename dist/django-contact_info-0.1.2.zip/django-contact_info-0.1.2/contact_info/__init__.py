__author__ = 'damien'
__version__ = '0.1.2'
default_app_config = 'contact_info.apps.ContactInfoConfig'
