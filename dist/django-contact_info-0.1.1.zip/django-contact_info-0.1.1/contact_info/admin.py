from django.contrib import admin
from contact_info.models import State, Country, Person, Phone, Email

class StateAdmin(admin.ModelAdmin):
    list_display = ['name', 'abbreviation']

class PersonAdmin(admin.ModelAdmin):
    fieldsets = (
        (None, {'fields': ('salutation', 'first_name', 'last_name', 'title', 'role', 'address', 'phone_numbers', 'new_phone_number_link', 'emails')})
    )

admin.site.register(State, StateAdmin)
admin.site.register(Country)
admin.site.register(Person)
admin.site.register(Phone)
admin.site.register(Email)